<?php
session_start();
require 'koneksi.php';

// proses login
if (!empty($_GET['aksi'] == 'login')) {
  // validasi text untuk filter karakter khusus dengan fungsi strip_tags()
  $user = $_POST['user'];
  $pass = $_POST['pass'];
  $sql = "SELECT * FROM user WHERE username = ? AND password = md5(?)";
  $row = $koneksi->prepare($sql);
  $row->execute(array($user, $pass));
  $count = $row->rowCount();

  if ($count > 0) {
    $result = $row->fetch();
    $_SESSION['ADMIN'] = $result;
    // status yang diberikan
    echo "<script>window.location='admin.php';</script>";
  } else {
    echo "<script>window.location='login.php?get=failed';</script>";
  }
}

if (!empty($_GET['aksi'] == 'logout')) {
  session_destroy();
  echo "<script>window.location='login.php?signout=success';</script>";
}


// TAMBAH Hero
if (!empty($_GET['aksi'] == "add-hero")) {
  $hero_text = $_POST['hero_text'];
  $hero_image_name = $_FILES['hero_image']['name'];
  $hero_image_size = $_FILES['hero_image']['size'];

  if ($hero_image_size > 2097152) {

    header("location:admin.php?page=add-hero&pesan=size");
  } else {

    if ($hero_image_name != "") {

      $ekstensi_izin = array('png', 'jpg', 'jepg', 'svg');
      $pisahkan_ekstensi = explode('.', $hero_image_name);
      $ekstensi = strtolower(end($pisahkan_ekstensi));
      $file_tmp = $_FILES['hero_image']['tmp_name'];
      $tanggal = md5(date('Y-m-d h:i:s'));
      $hero_image_name_new = $tanggal . '-' . $hero_image_name;

      if (in_array($ekstensi, $ekstensi_izin) === true) {

        move_uploaded_file($file_tmp, 'assets/img/hero/' . $hero_image_name_new);
        $query = mysqli_query($koneksi2, "INSERT INTO hero VALUES ('', '$hero_text', '$hero_image_name_new')");

        if ($query) {
          header("location:admin.php?page=add-hero&pesan=berhasil");
        } else {
          header("location:admin.php?page=add-hero&pesan=gagal");
        }
      } else {
        header("location:admin.php?page=add-hero&pesan=ekstensi");
      }
    } else {

      $query = mysqli_query($koneksi2, "INSERT INTO hero(hero_text) VALUES ('$hero_text')");

      if ($query) {
        header("location:admin.php?page=add-hero&pesan=berhasil");
      } else {
        header("location:admin.php?page=add-hero&pesan=gagal");
      }
    }
  }
}
//  END TAMBAH Hero

// EDIT Hero
if (!empty($_GET['aksi'] == "edit-hero")) {
  if (isset($_POST['id'])) {
    if ($_POST['id'] != "") {
      // Mengambil data dari form lalu ditampung didalam variabel
      $id = $_POST['id'];
      $hero_text = $_POST['hero_text'];
      $hero_image_name = $_FILES['hero_image']['name'];
      $hero_text_name = $_FILES['hero_image']['size'];
    } else {
      header("location:index.php");
    }

    // Mengecek apakah file lebih besar 2 MB atau tidak
    if ($hero_text_name > 2097152) {
      // Jika File lebih dari 2 MB maka akan gagal mengupload File
      header("location:index.php?pesan=size");
    } else {

      // Mengecek apakah Ada file yang diupload atau tidak
      if ($hero_image_name != "") {

        // Ekstensi yang diperbolehkan untuk diupload boleh diubah sesuai keinginan
        $ekstensi_izin = array('png', 'jpg', 'jepg', 'svg');
        $pisahkan_ekstensi = explode('.', $hero_image_name);
        $ekstensi = strtolower(end($pisahkan_ekstensi));
        $file_tmp = $_FILES['hero_image']['tmp_name'];
        $tanggal = md5(date('Y-m-d h:i:s'));
        $hero_image_name_new = $tanggal . '-' . $hero_image_name;

        if (in_array($ekstensi, $ekstensi_izin) === true) {

          $get_foto = "SELECT hero FROM hero_image WHERE id='$id'";
          $data_foto = mysqli_query($koneksi2, $get_foto);
          $foto_lama = mysqli_fetch_array($data_foto);

          unlink("assets/img/hero/" . $foto_lama['hero_image']);

          move_uploaded_file($file_tmp, 'assets/img/hero/' . $hero_image_name_new);

          $query = mysqli_query($koneksi2, "UPDATE hero SET hero_text='$hero_text', hero_image='$hero_image_name_new' WHERE id='$id'");

          if ($query) {
            header("location:index.php?pesan=berhasil");
          } else {
            header("location:index.php?pesan=gagal");
          }
        } else {
          header("location:index.php?pesan=ekstensi");
        }
      } else {

        $query = mysqli_query($koneksi2, "UPDATE hero SET hero_text='$hero_text' WHERE id='$id'");

        if ($query) {
          header("location:index.php?pesan=berhasil");
        } else {
          header("location:index.php?pesan=gagal");
        }
      }
    }
  } else {
    header("location:admin.php?page=hero");
  }
}
//  END EDIT Hero