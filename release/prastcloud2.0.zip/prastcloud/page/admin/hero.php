<h1 class="mt-4">Hero</h1>
<ol class="breadcrumb mb-4">
  <li class="breadcrumb-item active">Hero</li>
</ol>

<div class="row">
  <?php
  // jalankan query untuk menampilkan semua data diurutkan berdasarkan nim
  $query = "SELECT * FROM hero ORDER BY id ASC";
  $result = mysqli_query($koneksi2, $query);
  //mengecek apakah ada error ketika menjalankan query
  if (!$result) {
    die("Query Error: " . mysqli_errno($koneksi2) .
      " - " . mysqli_error($koneksi2));
  }
  $no = 1;
  while ($row = mysqli_fetch_assoc($result)) {
  ?>
  <div class="mb-4">
  <a href="admin.php?page=edit-hero&id=<?php echo $row['id']; ?>" class="btn btn-success">Edit</a>
</div>
  
    <div class="col-xl-6">
      <div class="card mb-4" style="height: 250px;">
        <div class="card-header">
          <i class="fas fa-chart-bar me-1"></i>
          Hero Text
        </div>
        <div class="card-body">
          <?php echo $row['hero_text']; ?>
        </div>
      </div>
    </div>
    <div class="col-xl-6">
      <div class="card mb-4" style="height: 250px;">
        <div class="card-header">
          <i class="fas fa-chart-area me-1"></i>
          Hero Image
        </div>
        <div class="card-body">
          <img src="assets/img/hero/<?php echo $row['hero_image']; ?>" style="width: 300px;">
        </div>
      </div>
    </div>


  <?php
    $no++;
  }
  ?>

</div>