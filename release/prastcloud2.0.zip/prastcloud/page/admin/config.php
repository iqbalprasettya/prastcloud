<?php
$page = (isset($_GET['page'])) ? $_GET['page'] : '';
switch ($page) {


    // Page
  case 'hero':
    include "page/admin/hero.php";
    break;

  case 'section1':
    include "page/admin/section1.php";
    break;

  case 'news':
    include "page/admin/news.php";
    break;

  case 'add-hero':
    include "page/admin/add-hero.php";
    break;

  case 'edit-hero':
    include "page/admin/edit-hero.php";
    break;

  default:
    include "page/admin/dashboard.php";
}
